<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloBreakOut extends Model
{
    protected $fillable = ['ciclos'];
}
