<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloBreakin extends Model
{
    protected $fillable = ['ciclos'];
}
