<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloCapa extends Model
{
    //
   
}
