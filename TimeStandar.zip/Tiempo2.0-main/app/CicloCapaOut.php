<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloCapaOut extends Model
{
    //
    
}
