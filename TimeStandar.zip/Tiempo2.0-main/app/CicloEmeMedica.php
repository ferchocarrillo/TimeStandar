<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloEmeMedica extends Model
{
    //
}
