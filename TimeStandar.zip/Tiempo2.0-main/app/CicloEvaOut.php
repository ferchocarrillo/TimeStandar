<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloEvaOut extends Model
{
    //
}
