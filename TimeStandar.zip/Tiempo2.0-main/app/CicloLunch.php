<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloLunch extends Model
{
    //
}
