<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloReunion extends Model
{
    //
}
