<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CicloSalida extends Model
{
    // protected $table='ciclos';
    protected $fillable = ['ciclos'];
}
