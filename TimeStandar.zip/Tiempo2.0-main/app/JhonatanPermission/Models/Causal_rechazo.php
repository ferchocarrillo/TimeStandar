<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Causales extends Model
{
    protected $fillable = ['causales'];
}
