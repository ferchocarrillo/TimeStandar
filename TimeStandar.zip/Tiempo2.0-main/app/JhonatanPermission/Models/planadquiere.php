<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Planadquiere extends Model
{
    protected $fillable = ['planventa'];
}
