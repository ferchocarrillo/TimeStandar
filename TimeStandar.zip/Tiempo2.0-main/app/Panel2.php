<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Panel2 extends Model
{
    protected $table='panels';

    protected $fillable = ['id','llave'];

}
