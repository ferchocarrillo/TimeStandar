<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PersonalActivo extends Model
{
    //
}
